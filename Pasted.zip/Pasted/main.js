// Esta variable la usará principalmente getAnswers para la creación inicial.
let answersElement = null;

const getSettings = () => {
  return new Promise((resolve) => {
    chrome.storage.local.get(['geminiApiKey', 'preloadPrompt'], (result) => {
      resolve(result);
    });
  });
};

const getTextAnswers = async (question = "", options = []) => {
  try {
    const { geminiApiKey, preloadPrompt } = await getSettings();
    if (!geminiApiKey) {
      console.error("Clave API de Gemini no configurada.");
      return "ERROR: Clave API no configurada.";
    }

    let prompt = `${preloadPrompt || ''}\n\nEstas a punto de tomar una prueba. Debes responder lo mas resumidamente posible. Da tu respuesta en este formato: 'Opcion: _ ':\n${question}\n\n`;
    if (options.length > 0) {
      prompt += `Las opciones son:\n`;
      options.forEach((opt, i) => {
        prompt += `${i + 1}. ${opt}\n`;
      });
    }

    const requestBody = {
      contents: [{ parts: [{ text: prompt }] }],
    };

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-pro:generateContent?key=${geminiApiKey}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestBody),
      }
    );

    const data = await response.json();

    if (response.ok) {
      return data.candidates[0].content.parts[0].text;
    } else {
      return `Error de API: ${data.error.message}`;
    }
  } catch (error) {
    return "Error.";
  }
};

const getImageAns = async (url, question = "", options = []) => {
  try {
    const { geminiApiKey, preloadPrompt } = await getSettings();
    if (!geminiApiKey) {
      console.error("Gemini API Key not set.");
      return "ERROR: API Key not set.";
    }

    let prompt = `${preloadPrompt || ''}\n\nPlease provide an answer for the following question, and in the end add the answer in the format : 'Option : _ ':\n${question}\n if no question, it must be in the image, use that question to find the answer\n`;
    if (options.length > 0) {
      prompt += `Options are:\n`;
      options.forEach((opt, i) => {
        prompt += `${i + 1}. ${opt}\n`;
      });
    }

    const imageResponse = await fetch(url);
    const imageBlob = await imageResponse.blob();
    const reader = new FileReader();
    reader.readAsDataURL(imageBlob);
    await new Promise(resolve => reader.onload = resolve);
    const base64Image = reader.result.split(',')[1];

    const requestBody = {
      contents: [{
        parts: [{ text: prompt }, { inline_data: { mime_type: imageBlob.type, data: base64Image } }],
      }],
    };

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${geminiApiKey}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestBody),
      }
    );
    const data = await response.json();
    if (response.ok) {
      return data.candidates[0].content.parts[0].text;
    } else {
      return `API Error: ${data.error.message}`;
    }
  } catch (error) {
    return "Failed to fetch response.";
  }
};

const getAnswers = async () => {
  // El script getAnswers.js llama a deleteAnswers() primero,
  // lo que limpia cualquier contenedor de respuestas anterior.
  //

  const questionElements = Array.from(
    document.querySelectorAll("div.Qr7Oae")
  ).map((el) => el.querySelector("div"));

  const solution = [];
  let promises = [];

  for (let i = 0; i < questionElements.length; i++) {
    promises.push(
      new Promise(async (resolve) => {
        try {
          const question = questionElements[i];
          const questionData = JSON.parse("[" + question.getAttribute("data-params").substring(4));
          const questionObject = questionData[0];
          let answer = "";

          const image = question.querySelector("img");
          if (image) {
            const url = image.src;
            const questionText = questionObject[1];
            const questionOptions = Array.from(questionObject[4][0][1]).map(el => el[0]);
            answer = await getImageAns(url, questionText, questionOptions);
            solution.push({ ind: i, answer });
          } else {
            const questionText = questionObject[1];
            const questionOptions = Array.from(questionObject[4][0][1]).map(el => el[0]);
            if (questionText && questionOptions.length > 0) {
              answer = await getTextAnswers(questionText, questionOptions, i + 1);
              solution.push({ ind: i, answer });
            }
          }
          resolve();
        } catch (error) {
          console.error(`Error en la pregunta ${i + 1}`, error);
          resolve();
        }
      })
    );
  }

  await Promise.all(promises);
  solution.sort((a, b) => a.ind - b.ind);

  const formattedAnswers = solution
    .map(s => `P${s.ind + 1}: ${s.answer.replace(/Opcion: /gi, '').trim()}`)
    .join(' | ');

  const referenceElement = document.querySelector('div.T2dutf');
  if (!referenceElement) {
    console.error("Elemento de referencia no encontrado.");
    return;
  }

  answersElement = document.createElement('div');
  answersElement.id = 'gpt-answers-container';
  answersElement.innerHTML = formattedAnswers;

  const style = window.getComputedStyle(referenceElement);
  for (const prop of style) {
    answersElement.style.setProperty(prop, style.getPropertyValue(prop));
  }
  
  answersElement.style.display = 'block';
  referenceElement.parentNode.insertBefore(answersElement, referenceElement);
};

const toggleAnswers = () => {
  // Busca el elemento por su ID cada vez, para no depender de la variable global.
  const container = document.getElementById('gpt-answers-container');
  if (!container) return;

  const isHidden = container.style.display === "none";
  container.style.display = isHidden ? "block" : "none";
};

const deleteAnswers = () => {
  // Busca el elemento por su ID para asegurarse de que siempre funcione.
  const container = document.getElementById('gpt-answers-container');
  if (container) {
    container.remove();
  }
  answersElement = null;
};