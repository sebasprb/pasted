deleteAnswers();
