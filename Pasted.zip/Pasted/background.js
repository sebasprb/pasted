chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension instalada. Creando menus...");
  const menuItems = [
    { id: "getAnswers", title: "Preguntar" },
    { id: "toggleAnswers", title: "Mostrar/Esconder" },
    { id: "eraseAnswers", title: "Borrar" },
  ];

  menuItems.forEach((item) => {
    chrome.contextMenus.create({
      id: item.id,
      title: item.title,
      contexts: ["all"],
    });
    console.log(`Menu de contexto creado: ${item.title}`);
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (tab?.id) {
    console.log(`Menu de contexto clickeado: ${info.menuItemId}`);
    executeScript(tab.id, `scripts/${info.menuItemId}.js`);
  } else {
    console.error("Sin actividad de pestaña para ejecutar el script.");
  }
});

chrome.commands.onCommand.addListener((command) => {
  console.log(`Comando recibido: ${command}`);

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs.length > 0) {
      const activeTabId = tabs[0].id;
      console.log(`Ejecutando comando '${command}' en ID: ${activeTabId}`);
      executeScript(activeTabId, `scripts/${command}.js`);
    } else {
      console.error("Sin pestañas activas para ejecutar el comando.");
    }
  });
});

function executeScript(tabId, scriptFile) {
  console.log(`Executing script: ${scriptFile} on tab ID: ${tabId}`);

  chrome.scripting.executeScript(
    {
      target: { tabId: tabId },
      files: [scriptFile],
    },
    () => {
      if (chrome.runtime.lastError) {
        console.error(
          `Error executing script '${scriptFile}': ${chrome.runtime.lastError.message}`
        );
      } else {
        console.log(`Script executed successfully: ${scriptFile}`);
      }
    }
  );
}
