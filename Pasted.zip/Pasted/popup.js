document.addEventListener('DOMContentLoaded', () => {
  const apiKeyInput = document.getElementById('apiKey');
  const preloadPromptInput = document.getElementById('preloadPrompt');
  const saveButton = document.getElementById('saveButton');
  const statusDiv = document.getElementById('status');

  // Load saved settings when the popup is opened
  chrome.storage.local.get(['geminiApiKey', 'preloadPrompt'], (result) => {
    if (result.geminiApiKey) {
      apiKeyInput.value = result.geminiApiKey;
    }
    if (result.preloadPrompt) {
      preloadPromptInput.value = result.preloadPrompt;
    }
  });

  // Save settings when the "Save" button is clicked
  saveButton.addEventListener('click', () => {
    const apiKey = apiKeyInput.value;
    const preloadPrompt = preloadPromptInput.value;

    if (!apiKey) {
      statusDiv.textContent = 'Clave API es requerida.';
      statusDiv.style.color = 'red';
      return;
    }

    chrome.storage.local.set({ geminiApiKey: apiKey, preloadPrompt: preloadPrompt }, () => {
      statusDiv.textContent = 'Configuracion aplicada.';
      statusDiv.style.color = 'green';
      setTimeout(() => statusDiv.textContent = '', 2000);
    });
  });
});